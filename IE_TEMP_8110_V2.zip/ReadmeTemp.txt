This file contains monthly, seasonal and annual 1981-2010 Maximum, Minimum and Mean Temperatures on a 1X1km grid
Coordinates are Irish Grid: http://www.osi.ie/Services/GPS-Services/Reference-Information/Irish-Grid-Reference-System.aspx
Temperatures are in degrees Celsius and tenths.

v1 - May 2012
V2 - July 2012, correction made to annaul and seasol values, V1 had annual values twice and only 3 seasoal values which were out of sequence


Interim reference pending publication:
Walsh S., 2012: A Summary of Climate Averages 1981-2010 for Ireland, Climatological Note No.14, Met �ireann, Dublin.

Data in this file are (c)  copywrite Met �ireann